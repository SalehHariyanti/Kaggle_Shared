import os
import datetime
from dsb2018_config import *
from dataset import DSB2018_Dataset
import numpy as np
import model as modellib
import functions as f
from settings import test_dir, submissions_dir, supplementary_dir
import utils
import dsb2018_utils as du
import scipy
import cv2
from copy import deepcopy
from tqdm import tqdm

import visualize
from visualize import image_with_masks, plot_multiple_images
import matplotlib.pyplot as plt

import train
import getpass
                    
def base_test_dataset():
    dataset = DSB2018_Dataset()
    dataset.add_nuclei(test_dir, 'test')
    dataset.prepare()
    return dataset


def combine_results(_results, N, iou_threshold, voting_threshold, param_dict, use_nms, use_semantic):

    results = []
    for i in range(N):

        img_results = du.concatenate_list_of_dicts([rf[i] for rf in _results])
        if use_nms:
            img_results = reduce_via_nms(img_results, threshold)
        else:
            img_results = reduce_via_voting(img_results, iou_threshold, voting_threshold, param_dict, use_semantic, n_votes = len(_results))

        # Reshape masks
        img_results['masks'] = np.moveaxis(img_results['masks'], 0, -1)
        img_results['class_ids'] = img_results['class_ids'].reshape(-1, )
        img_results['scores'] = img_results['scores'].reshape(-1, )

        results.append(img_results)

    return results


def apply_flips_rotations(_config, images, param_dict):

    images_flip = [images, 
                [np.fliplr(img) for img in images], 
                [np.flipud(img) for img in images],
                [np.flipud(np.fliplr(img)) for img in images],
                [np.rot90(img, 1, (0, 1)) for img in images],
                [np.rot90(img, 3, (0, 1)) for img in images]]

    output = {'images': images_flip,
              'mask_scale': [None] * len(images_flip),
              'fn_reverse': 'reverse_flips_rotations'}

    return output


def reverse_flips_rotations(results_flip, images, use_semantic):

    for i in range(len(images)):

        results_flip[1][i]['masks'] = np.fliplr(results_flip[1][i]['masks'])
        results_flip[2][i]['masks'] = np.flipud(results_flip[2][i]['masks'])
        results_flip[3][i]['masks'] = np.fliplr(np.flipud(results_flip[3][i]['masks']))
        results_flip[4][i]['masks'] = np.rot90(results_flip[4][i]['masks'], -1, (0, 1))
        results_flip[5][i]['masks'] = np.rot90(results_flip[5][i]['masks'], -3, (0, 1))

        if use_semantic:

            results_flip[1][i]['semantic_masks'] = np.fliplr(results_flip[1][i]['semantic_masks'])
            results_flip[2][i]['semantic_masks'] = np.flipud(results_flip[2][i]['semantic_masks'])
            results_flip[3][i]['semantic_masks'] = np.fliplr(np.flipud(results_flip[3][i]['semantic_masks']))
            results_flip[4][i]['semantic_masks'] = np.rot90(results_flip[4][i]['semantic_masks'], -1, (0, 1))
            results_flip[5][i]['semantic_masks'] = np.rot90(results_flip[5][i]['semantic_masks'], -3, (0, 1))

        # Recalculate bboxes
        for j in range(len(results_flip)):
            results_flip[j][i]['rois'] = utils.extract_bboxes(results_flip[j][i]['masks'])
            # Reshape masks so that they can be concatenated correctly
            results_flip[j][i]['masks'] = np.moveaxis(results_flip[j][i]['masks'], -1, 0)
            if use_semantic:
                results_flip[j][i]['semantic_masks'] = np.moveaxis(results_flip[j][i]['semantic_masks'], -1, 0)

    return results_flip


def apply_scaling(_config, images, param_dict):
    """
    Extract the images that would normally be fed into maskrcnn and rescale from here
    NB: because of how maskrcnn resizes, images are scaled up to reach 
    (_config.IMAGE_MIN_DIM, _config.IMAGE_MAX_DIM) as standard.
    As a result, if we have scales > 1 the images will end up being scaled back down to the 
    maximum anyway. So we can only generate different scaled inputs by scaling downwards.
    Hence default scales set to 0.8, 0.9, 1.
    """

    assert 'scales' in param_dict.keys()
    scales = param_dict['scales']

    # Note: output of utils is: image, window, scale, padding
    model_inputs = [utils.resize_image(img, min_dim = _config.IMAGE_MIN_DIM, max_dim = _config.IMAGE_MAX_DIM, padding = _config.IMAGE_PADDING) for img in images]
    # Take the image window out of the model image inputs (the rest is padding)
    model_images_ex_padding = [x[0][x[1][0] : x[1][2], x[1][1] : x[1][3]] for x in model_inputs]
   
    # Create output
    output = {'images': [model_images_ex_padding for scale in scales],
              'mask_scale': [[scale] * len(images) for scale in scales],
              'fn_reverse': 'reverse_scaling'}
    
    return output


def reverse_scaling(results_scale, images, use_semantic):

    # Reverse the scales
    for i in range(len(images)):
        for j in range(len(results_scale)):

            results_scale[j][i]['masks'] = scipy.ndimage.zoom(results_scale[j][i]['masks'], 
                                                              (images[i].shape[0] / results_scale[j][i]['masks'].shape[0], 
                                                               images[i].shape[1] / results_scale[j][i]['masks'].shape[1], 
                                                               1), order = 0)
            results_scale[j][i]['rois'] = utils.extract_bboxes(results_scale[j][i]['masks'])
            # Reshape masks so that they can be concatenated correctly
            results_scale[j][i]['masks'] = np.moveaxis(results_scale[j][i]['masks'], -1, 0)

            if use_semantic:
                results_scale[j][i]['semantic_masks'] = scipy.ndimage.zoom(results_scale[j][i]['semantic_masks'], 
                                                                  (images[i].shape[0] / results_scale[j][i]['semantic_masks'].shape[0], 
                                                                   images[i].shape[1] / results_scale[j][i]['semantic_masks'].shape[1], 
                                                                   1), order = 0)
                # Reshape masks so that they can be concatenated correctly
                results_scale[j][i]['semantic_masks'] = np.moveaxis(results_scale[j][i]['semantic_masks'], -1, 0)


    return results_scale


def apply_clahe(_config, images, param_dict):
    """
    Apply CLAHE colour transform to images
    """

    assert 'clahe' in param_dict.keys()
    clip, grid = param_dict['clahe']

    c = cv2.createCLAHE(clipLimit = clip, tileGridSize = (grid, grid)) 

    clahe_images = []

    for img in images:
        lab = cv2.cvtColor(img, cv2.COLOR_RGB2LAB)
        l_channel, a_channel, b_channel = cv2.split(lab)
        l_channel = c.apply(l_channel)
        lab   = cv2.merge((l_channel, a_channel, b_channel))
        clahe_images.append(cv2.cvtColor(lab, cv2.COLOR_LAB2RGB))
   
    # Create output
    output = {'images': clahe_images,
              'mask_scale': [None] * len(clahe_images),
              'fn_reverse': 'reverse_clahe'}
    
    return output


def reverse_clahe(results, images):

    return results


def maskrcnn_detect_augmentations(_config, model, images, list_fn_apply, threshold, voting_threshold = 0.5, param_dict = {}, use_nms = False, use_semantic = False):
    """
    Augments images subject to list_fn_apply and combines results via 
    non-maximum suppression if use_nms is True, otherwises uses merging + voting
    """

    # Apply the augmentations requested
    # NB: augmentations must include the original (unaugmented) image, if requested
    # fn_apply returns: lists of images and corresponding mask_scale, fn_reverse
    images_info = [globals()[fn_apply](_config, images, param_dict) for fn_apply in list_fn_apply]

    results_augment = []

    for img_info in images_info:
        
        # Each img_info set corresponds to a set of augmentations.
        # It has the following information:
        # 'images': the set of augmented images that we require predictions for (e.g. a set of 6 flips/rotations)
        # 'mask_scale': the mask_scale that we want to apply when resizing images with resize_image_scaled() (if you want to use normal resizing set mask_scale = None)
        # 'fn_reverse': the function to call to reverse the augmentations from the predicted masks

        # Detect
        if use_semantic:
            # In this instance we need to detect with expand_semantic = True, 
            # as because we are combining results over multiple augmentations 
            # it is easier to have one semantic instance for each mask instance
            res = [model.detect(img, verbose=0, mask_scale = mask_scale, expand_semantic = True) for img, mask_scale in zip(img_info['images'], img_info['mask_scale'])]
        else:
            res = [model.detect(img, verbose=0, mask_scale = mask_scale) for img, mask_scale in zip(img_info['images'], img_info['mask_scale'])]

        # Reverse augmentations
        res = globals()[img_info['fn_reverse']](res, images, use_semantic)

        # Append
        for r in res:
            results_augment.extend(res)
    
    # Concatenate lists of results
    results_augment = du.concatenate_list_of_dicts(results_augment) 

    if not isinstance(results_augment, list):
        results_augment = [[results_augment]]

    # Carry out either non-maximum suppression or merge+voting to reduce results_flip for each image to a single set of results
    results = combine_results(results_augment, len(images), threshold, voting_threshold, param_dict, use_nms, use_semantic)

    return results


def maskrcnn_detect(_config, model, images, param_dict = {}, use_semantic = False):

    results = model.detect(images, verbose=0)

    if use_semantic:
        for r in results:
            r['masks'] = combine_semantic(r['rois'], r['scores'], r['masks'], r['semantic_masks'], param_dict)

    return results


def maskrcnn_detect_tiles(model, images, grid_shape = (2, 2), nms_threshold = 0.3, nms_tiles = False):
    """
    Splits images into tiles and combines results.
    If nms_tiles = True, the tiled results are combined with those for the original image.
    If nms_tiles = False, tiled results that are not on the border are used, and combined with results for the original image that do not overlap with tiled masks.
    """
    
    n_images = len(images)
    n_grid = np.product(grid_shape)
    border_pixel_threshold = 5

    # grid_data = (grid, x, y, per_col, per_row, pad_col, pad_row) for each image
    grid_data = [create_tile_template(img.shape, grid_shape) for img in images]

    # Tile original images
    images_tiled = [tile_image(img, grid) for img, grid in zip(images, grid_data)]

    # Reorder so that you have n images x m tiles
    images_tiled = [[images_tiled[j][i] for j in range(n_images)] for i in range(n_grid)]
    
    # Detect (results in orginal format)
    results_tiles = [model.detect(imgs, verbose = 0) for imgs in images_tiled]

    # Combine back from tiles to original
    masks_retiled = [[]] * n_images
    masks_retiled_scores = [[]] * n_images
    masks_retiled_class_ids = [[]] * n_images
    for i in range(n_images):

        for j in range(n_grid):

            # We will be ignoring any masks from the tiles that are too close to borders as these are unreliable.
            # (You will replace these with nuclei from the original mask)
            border_pixels = np.ones(results_tiles[j][i]['masks'].shape)
            border_pixels[border_pixel_threshold : -border_pixel_threshold, border_pixel_threshold : -border_pixel_threshold] = 0

            valid_mask = np.logical_and(np.sum(np.multiply(results_tiles[j][i]['masks'], border_pixels), axis = (0, 1)) == 0,
                                        np.sum(results_tiles[j][i]['masks'], axis = (0, 1)) > 0)

            if False: 
                #Sanity checking...
                visualize.plot_multiple_images([(images[i]*255).astype(np.uint8),
                                                (images[i]*255).astype(np.uint8),
                                                du.maskrcnn_mask_to_labels(results_tiles[0][i]['masks']),
                                                du.maskrcnn_mask_to_labels(results_tiles[1][i]['masks']),
                                                du.maskrcnn_mask_to_labels(results_tiles[2][i]['masks']),
                                                du.maskrcnn_mask_to_labels(results_tiles[3][i]['masks'])],
                                               nrows = 3, ncols = 2)

                visualize.plot_multiple_images([du.maskrcnn_mask_to_labels(results_tiles[j][i]['masks']), 
                                                du.maskrcnn_mask_to_labels(results_tiles[j][i]['masks'][:, :, valid_mask])], nrows = 1, ncols = 2)

            this_n_masks = np.sum(valid_mask)

            if this_n_masks > 0:

                this_mask = np.zeros(grid_data[i][0].shape + (this_n_masks,), dtype = np.int)
                this_mask[grid_data[i][0] == j + 1] = results_tiles[j][i]['masks'][:, :, valid_mask].reshape(-1, this_n_masks)

                if len(masks_retiled[i]) == 0:
                    masks_retiled[i] = np.moveaxis(this_mask, -1, 0)
                    masks_retiled_scores[i] = results_tiles[j][i]['scores'][valid_mask]
                    masks_retiled_class_ids[i] = results_tiles[j][i]['class_ids'][valid_mask]
                else:
                    masks_retiled[i] = np.concatenate((masks_retiled[i], np.moveaxis(this_mask, -1, 0)))
                    masks_retiled_scores[i] = np.concatenate((masks_retiled_scores[i], results_tiles[j][i]['scores'][valid_mask]))
                    masks_retiled_class_ids[i] = np.concatenate((masks_retiled_class_ids[i], results_tiles[j][i]['class_ids'][valid_mask]))

            else:

                masks_retiled[i] = np.zeros((1, ) + grid_data[i][0].shape, dtype = np.int)
                masks_retiled_scores[i] = np.array([0])
                masks_retiled_class_ids[i] = np.array([0])

    results_retiled = [{'masks': mask_retiled[:, :images[i].shape[0], :images[i].shape[1]], 
                        'scores': mask_retiled_score,
                        'class_ids': mask_retiled_class_id,
                        'rois': utils.extract_bboxes(np.moveaxis(mask_retiled, 0, -1))} 
                        for i, (mask_retiled, mask_retiled_score, mask_retiled_class_id) in enumerate(zip(masks_retiled, masks_retiled_scores, masks_retiled_class_ids))]
        
    # Detect original results
    results_orig = model.detect(images, verbose = 0)
    # Reshape masks so that they are compatible with pu.concatenate_list_of_dicts
    for r in results_orig:
        r['masks'] = np.moveaxis(r['masks'], -1, 0)
        
    # Reduce each image to a single set of results, combining the original with the tiled version
    results = []
    for i in range(len(images)):

        if nms_tiles:
            # Carry out NMS of the original with the tiled version (less borders)
            img_results_retiled = du.concatenate_list_of_dicts([results_orig[i], results_retiled[i]])
            nms_idx = utils.non_max_suppression(img_results_retiled['rois'], img_results_retiled['scores'].reshape(-1, ), nms_threshold)
            img_results_retiled = du.reduce_dict(img_results_retiled, nms_idx)
        else:
            # Use the masks from the original that do not overlap with the tiled version
            # and let the tiled version take preference for non-border nuclei
            overlap = np.sum(np.multiply(results_orig[i]['masks'], np.expand_dims(np.sum(results_retiled[i]['masks'], axis = 0), 0)), axis = (1, 2)) > 0
            valid_orig = overlap == 0

            #visualize.plot_multiple_images([du.maskrcnn_mask_to_labels(np.moveaxis(results_orig[i]['masks'], 0, -1)), du.maskrcnn_mask_to_labels(np.moveaxis(results_orig[i]['masks'][valid_orig, :, :], 0, -1))], nrows = 1, ncols = 2) 

            results_orig[i]['masks'] = results_orig[i]['masks'][valid_orig]
            results_orig[i]['scores'] = results_orig[i]['scores'][valid_orig]
            results_orig[i]['rois'] = results_orig[i]['rois'][valid_orig]
            results_orig[i]['class_ids'] = results_orig[i]['class_ids'][valid_orig]

            img_results_retiled = du.concatenate_list_of_dicts([results_orig[i], results_retiled[i]])

        # Reshape elements as required
        img_results_retiled['masks'] = np.moveaxis(img_results_retiled['masks'], 0, -1)
        img_results_retiled['class_ids'] = img_results_retiled['class_ids'].reshape(-1, )
        img_results_retiled['scores'] = img_results_retiled['scores'].reshape(-1, )

        results.append(img_results_retiled)


    if False:
        # Sanity checking...
        visualize.plot_multiple_images([(images[0] * 255).astype(np.uint8), 
                                    du.maskrcnn_mask_to_labels(np.moveaxis(results_retiled[0]['masks'], 0, -1)),
                                    du.maskrcnn_mask_to_labels(np.moveaxis(results_orig[0]['masks'], 0, -1)),
                                    du.maskrcnn_mask_to_labels(results[0]['masks'])], 
                                    ['img', 'tiled predictions (less borders)', 'orig predictions', 'combined predictions'], 1, 4)

    return results


def reduce_via_nms(img_results, threshold):
    nms_idx = utils.non_max_suppression(img_results['rois'], img_results['scores'].reshape(-1, ), threshold)
    return du.reduce_dict(img_results, nms_idx)


def reduce_via_voting(img_results, threshold, voting_threshold, param_dict, use_semantic, n_votes):
    """
    Merges masks from different sets of results if their bboxes overlap by > threshold.
    Then takes a pixel-level vote on which pixels should be included in each mask (> voting threshold).
    """
    results = deepcopy(img_results)
   
    # Combine masks with overlaps greater than threshold
    if use_semantic:
        idx, boxes, scores, masks, n_joins, semantic_masks = du.combine_boxes(results['rois'], results['scores'].reshape(-1, ), np.moveaxis(results['masks'], 0, -1), threshold, np.moveaxis(results['semantic_masks'], 0, -1))
    else:
        idx, boxes, scores, masks, n_joins = du.combine_boxes(results['rois'], results['scores'].reshape(-1, ), np.moveaxis(results['masks'], 0, -1), threshold)

    # Select masks based on voting threshold
    avg_masks = masks / n_votes
    masks = (np.multiply(masks, avg_masks > voting_threshold) > 0).astype(np.int)
    valid_masks = np.sum(masks, axis = (0, 1)) > 0

    # Reduce to masks that are still valid
    idx = idx[valid_masks]
    boxes = boxes[valid_masks]
    masks = masks[:, :, valid_masks]
    scores = scores[valid_masks]

    if use_semantic:
        # Reduce semantic masks according to valid_masks and voting_threshold
        avg_semantic_masks = semantic_masks / n_votes
        semantic_masks = (avg_semantic_masks[:, :, valid_masks] > voting_threshold).astype(np.int)
        # Reduce to single semantic mask
        semantic_masks = (np.sum(semantic_masks, axis = -1) > 0).astype(np.int)

        masks = combine_semantic(boxes, scores, masks, semantic_masks, param_dict)

    #from visualize import plot_multiple_images; plot_multiple_images([np.sum(img_results['masks'], axis = 0), np.sum(masks, axis = 0)], nrows = 1, ncols = 2)
    
    # Assign results to img_results:

    # Reduce dict to the relevant index to capture the relevant fields for anything
    # you haven't changed
    img_results = du.reduce_dict(img_results, idx)
     
    # Assign newly calculated fields
    img_results['rois'] = boxes
    img_results['masks'] = np.moveaxis(masks, -1, 0)
    img_results['scores'] = scores
    if use_semantic:
        img_results['semantic_masks'] = semantic_masks

    return img_results


def combine_semantic(boxes, scores, masks, semantic_masks, param_dict):
    """
    For each semantic_mask pixel that falls within the box of a mask
    we assign that pixel to the mask with the highest score.
    """

    n_dilate = param_dict['n_dilate'] if 'n_dilate' in param_dict else 1
    n_erode = param_dict['n_erode'] if 'n_erode' in param_dict else 0

    if n_dilate > 0 or n_erode > 0:

        # Make a mask of box labels
        box_labels = du.maskrcnn_boxes_to_labels(boxes, scores, semantic_masks.shape)

        # Each mask lies between an eroded version of itself and 
        # a dilated version of itself, the pixels in between 
        # being dictated by the overlap with semantic.
        for i in range(masks.shape[-1]):

            # Step 1: find the overlap with semantic. 
            original_overlap = np.multiply(masks[:, :, i], semantic_masks)

            # Step 2: erode the mask.
            eroded_mask = scipy.ndimage.morphology.binary_erosion(masks[:, :, i], iterations = n_erode) if n_erode > 0 else masks[:, :, i]
            eroded_plus_overlap = ((eroded_mask + original_overlap) > 0).astype(np.int)

            # Step 3: dilate the mask within box boundaries and find overlap with semantic
            dilated_mask = scipy.ndimage.morphology.binary_dilation(masks[:, :, i], iterations = n_dilate) if n_dilate > 0 else masks[:, :, i]
            dilated_overlap = np.multiply(dilated_mask, np.multiply(box_labels == (i + 1), semantic_masks))

            # Step 4: combine: new mask = eroded mask + original overlap + dilated overlap
            masks[:, :, i] = ((eroded_plus_overlap + dilated_overlap) > 0).astype(np.int)

        # from visualize import plot_multiple_images; plot_multiple_images([original_overlap, eroded_mask, eroded_plus_overlap, ((eroded_plus_overlap + dilated_overlap) > 0).astype(np.int), masks[:, :, i]])
        # from visualize import plot_multiple_images; plot_multiple_images([original_overlap, eroded_mask, dilated_mask, ((eroded_plus_overlap + dilated_overlap) > 0).astype(np.int), masks[:, :, i], np.abs(((eroded_plus_overlap + dilated_overlap) > 0).astype(np.int) - masks[:,:,i])], nrows = 2, ncols = 3)

    return masks


def old_combine_semantic(boxes, scores, masks, semantic_masks):
    """
    For each semantic_mask pixel that falls within the box of a mask
    we assign that pixel to the mask with the highest score.
    """

    # Make a mask of box labels
    box_labels = du.maskrcnn_boxes_to_labels(boxes, scores, semantic_masks.shape)

    # Determine which pixels feature in semantic_masks but not masks
    masks_to_semantic = (np.sum(masks, axis = -1) > 0).astype(np.int)
    residual_semantic = np.logical_and(masks_to_semantic == 0, semantic_masks == 1).astype(np.int)

    # Determine which residual pixels overlap with box labels
    box_overlap = np.multiply(box_labels, residual_semantic)

    # For each unique case in box_overlap, dilate the mask and then assign the dilated pixels if they overlap with residual_semantic 
    boxes_with_overlap = np.unique(box_overlap[box_overlap > 0])
    for b in boxes_with_overlap:
        # NB: boxes_with_overlap are indexed + 1 relative to masks (to account for background of zero)
        dilated_mask = cv2.dilate(masks[:, :, b - 1].astype(np.uint8), kernel = np.array([[0, 1, 0], [1, 1, 1], [0, 1, 0]], dtype = np.uint8))
        masks[:, :, b - 1] = ((masks[:, :, b - 1] + np.multiply(dilated_mask, (box_overlap == b))) > 0).astype(np.int)

    # from visualize import plot_multiple_images; plot_multiple_images([masks_to_semantic, semantic_masks, residual_semantic, (np.sum(masks, axis = -1) > 0).astype(np.int)])
    # plot_multiple_images([masks_to_semantic, semantic_masks, residual_semantic, (np.sum(masks, axis = -1) > 0).astype(np.int)])
    return masks


def tile_image(img, grid):

    grid_template, x, y, per_col, per_row, pad_col, pad_row = grid

    tiled_img = np.zeros(grid_template.shape if img.ndim == 2 else grid_template.shape + (img.shape[-1],))
    tiled_img[:img.shape[0], :img.shape[1]] = img

    if img.ndim == 2:
        tiled_output = [tiled_img[grid_template == i].reshape((x, y)) for i in range(1, int(grid_template.max() + 1))]
    else:
        tiled_output = [np.stack([_tiled_img[grid_template == i].reshape((x, y)) 
                                    for _tiled_img in list(np.moveaxis(tiled_img, -1, 0))], axis = -1) 
                        for i in range(1, int(grid_template.max() + 1))]

    return tiled_output


def create_tile_template(img_shape, grid_shape):

    x, y = int(np.ceil(img_shape[0] / grid_shape[0])), int(np.ceil(img_shape[1] / grid_shape[1]))
    per_col, per_row = grid_shape[0], grid_shape[1]
    pad_col, pad_row = (x * grid_shape[0]) - img_shape[0], (y * grid_shape[1]) - img_shape[1]

    single_tile = np.ones((x, y))

    row = np.concatenate([single_tile * (i + 1) for i in range(per_row)], axis =1)
    grid = np.concatenate([row + i for i in per_row * np.arange(per_col)], axis = 0)

    return grid, x, y, per_col, per_row, pad_col, pad_row


def create_model(_config, model_name, epoch = None):
    # Recreate the model in inference mode
    model = getattr(modellib, model_name)(mode="inference", 
                                config=_config,
                                model_dir=_config.MODEL_DIR)

    # Get path to saved weights
    # Either set a specific path or find last trained weights
    # model_path = os.path.join(ROOT_DIR, ".h5 file name here")
    if epoch is not None:
        model_path = model.find_last()[1][:-7] + '00' + str(epoch) + '.h5'
    else:
        model_path = model.find_last()[1]

    # Load trained weights (fill in path to trained weights here)
    assert model_path != "", "Provide path to trained weights"
    print("Loading weights from ", model_path)
    model.load_weights(model_path, by_name=True)

    return model


def load_dataset_images(dataset, i, batch_size):
    # Load image
    images = []
    for idx in range(i, i + batch_size):
        if idx < len(dataset.image_ids):
            images.append(dataset.load_image(dataset.image_ids[idx]))
        else:
            images.append(images[-1])
    return images


def combine_mosaics(_orig_names, _orig_mosaic_position, _orig_scores, _orig_labels, _mosaic_labels, _mosaic_scores):

    orig_mosaic_names = [_orig_names[_orig_mosaic_position == 'down_left'][0],
                            _orig_names[_orig_mosaic_position == 'down_right'][0],
                            _orig_names[_orig_mosaic_position == 'up_left'][0],
                            _orig_names[_orig_mosaic_position == 'up_right'][0]]

    orig_mosaic_scores = [_orig_scores[_orig_mosaic_position == 'down_left'][0],
                            _orig_scores[_orig_mosaic_position == 'down_right'][0],
                            _orig_scores[_orig_mosaic_position == 'up_left'][0],
                            _orig_scores[_orig_mosaic_position == 'up_right'][0]]

    orig_mosaic_labels = [_orig_labels[_orig_mosaic_position == 'down_left'][0],
                            _orig_labels[_orig_mosaic_position == 'down_right'][0],
                            _orig_labels[_orig_mosaic_position == 'up_left'][0],
                            _orig_labels[_orig_mosaic_position == 'up_right'][0]]

    # Divide the mosaic prediction into four original predictions
    full_mosaic_labels = [_mosaic_labels[orig_mosaic_labels[1].shape[0]:, :orig_mosaic_labels[0].shape[1]],
                            _mosaic_labels[orig_mosaic_labels[1].shape[0]:, orig_mosaic_labels[0].shape[1]:],
                            _mosaic_labels[:orig_mosaic_labels[1].shape[0], :orig_mosaic_labels[0].shape[1]],
                            _mosaic_labels[:orig_mosaic_labels[1].shape[0]:, orig_mosaic_labels[0].shape[1]:]]

    # Extract the scores relating to each part of the divided mosaic
    full_mosaic_scores = []
    for l in full_mosaic_labels:
        unique_labels = np.unique(l).astype(np.int)
        score_idx = unique_labels[unique_labels > 0] - 1
        full_mosaic_scores.append(_mosaic_scores[score_idx])

    # Combine the two, giving preference to full_mosaic_labels
    output = [combine_labels([fl, l], [fs, s]) for fl, l, fs, s in zip(full_mosaic_labels, 
                                                                        orig_mosaic_labels, 
                                                                        full_mosaic_scores, 
                                                                        orig_mosaic_scores)]
    final_labels = [o[0] for o in output]
    final_scores = [o[1] for o in output]

    return final_labels, final_scores, orig_mosaic_names


def combine_labels(label_list, score_list, border_threshold = 5):
    """
    label_list, score_list: length 2
    First element corresponds to your baseline predictions.
    The second corresponds to the predictions you wish to use provided
    they do not overlap with your baseline predictions and that they are not within
    border_threshold of the edge.
    """

    final_labels = label_list[0].copy()

    overlap = np.multiply(label_list[0] > 0, label_list[1] > 0)

    border = np.ones_like(overlap); border[border_threshold : -border_threshold, border_threshold : -border_threshold] = 0

    # A label from the second set is invalid if it overlaps with the first set, or if it broaches the border
    invalid_overlap = np.unique(label_list[1][np.multiply(label_list[1], overlap) > 0])
    invalid_border = np.unique(label_list[1][np.multiply(label_list[1], border) > 0])

    # Zero out invalid labels
    label_f = label_list[1].flatten()
    label_f[du.ismember(label_f, np.concatenate((invalid_overlap, invalid_border)), index_requested = False)] = 0
    # Visual:
    if False:
        from visualize import plot_multiple_images; plot_multiple_images(label_list + [label_f.reshape(final_labels.shape)], nrows = 1, ncols = 3)

    # Retrieve the scores corresponding to the labels you have left
    add_labels = np.unique(label_f).astype(np.int)
    add_scores = score_list[1][add_labels[add_labels > 0] - 1]

    # Artifically add final_labels.max() to the additional labels so that they don't clash when combined
    label_f[label_f > 0] = label_f[label_f > 0] + final_labels.max()

    # Create final labels
    final_labels = final_labels + label_f.reshape(final_labels.shape)
    # Rebase to start from 1 -> N without gaps
    final_labels = du.create_id(final_labels.flatten()).reshape(final_labels.shape)
    # Create final scores
    final_scores = np.concatenate((score_list[0], add_scores))

    return final_labels, final_scores


def predict_model(_config, dataset, model_name='MaskRCNN', epoch = None, 
                  augment_flips = False, augment_scale = False, 
                  param_dict = {},
                  nms_threshold = 0.3, voting_threshold = 0.5,
                  use_semantic = False,
                  img_pad = 0, dilate = False, 
                  save_predictions = False, create_submission = True):

    # Create save_dir
    if save_predictions:
        save_dir = os.path.join(data_dir, _config.NAME, '_'.join(('submission', datetime.datetime.now().strftime('%Y%m%d%H%M%S'))))
        os.makedirs(save_dir)

    # Recreate the model in inference mode
    model = create_model(_config, model_name, epoch)
      
    ImageId = []
    EncodedPixels = []
    
    list_fn_apply = [] + (['apply_flips_rotations'] if augment_flips else []) + (['apply_scaling'] if augment_scale else [])
    
    if dilate:
        n_dilate = param_dict['n_dilate'] if 'n_dilate' in param_dict else 1

    # NB: we need to predict in batches of _config.BATCH_SIZE
    # as there are layers within the model that have strides dependent on this.
    for i in tqdm(range(0, len(dataset.image_ids), _config.BATCH_SIZE)):
         # Load image
        images = []
        N = 0
        for idx in range(i, i + _config.BATCH_SIZE):
            if idx < len(dataset.image_ids):
                N += 1
                if img_pad > 0:
                    img = dataset.load_image(dataset.image_ids[idx])                  
                    images.append(np.stack([np.pad(img[:, :, i], img_pad, mode = 'reflect') for i in range(img.shape[-1])], axis = -1))
                else:
                    images.append(dataset.load_image(dataset.image_ids[idx]))
            else:
                images.append(images[-1])

        # Run detection
        if len(list_fn_apply) > 0:
            r = maskrcnn_detect_augmentations(_config, model, images, list_fn_apply, 
                                              threshold = nms_threshold, voting_threshold = voting_threshold, 
                                              param_dict = param_dict, 
                                              use_nms = False, use_semantic = use_semantic)
        else:
            r = maskrcnn_detect(_config, model, images, param_dict = param_dict, use_semantic = use_semantic) 

        # Reduce to N images
        for j, idx in enumerate(range(i, i + _config.BATCH_SIZE)):      

            if j < N:   

                masks = r[j]['masks'] #[H, W, N] instance binary masks
                scores = r[j]['scores']
                boxes = r[j]['rois']

                if img_pad > 0:

                    if use_semantic:
                        r[j]['semantic_masks'] = r[j]['semantic_masks'][img_pad : -img_pad, img_pad : -img_pad]

                    masks = masks[img_pad : -img_pad, img_pad : -img_pad]
                    valid = np.sum(masks, axis = (0, 1)) > 0
                    masks = masks[:, :, valid]

                    r[j]['masks'] = masks
                    r[j]['scores'] = r[j]['scores'][valid]
                    r[j]['class_ids'] = r[j]['class_ids'][valid]
                    r[j]['rois'] = r[j]['rois'][valid]
   
                if dilate:

                    # Dilate masks within boundary box perimeters
                    box_labels = du.maskrcnn_boxes_to_labels(boxes, scores, masks.shape[:2])
                    dilated_masks = []
                    for i in range(masks.shape[-1]):
                        dilated_mask = scipy.ndimage.morphology.binary_dilation(masks[:, :, i], iterations = n_dilate)
                        #from visualize import plot_multiple_images, image_with_masks;                   
                        #plot_multiple_images([image_with_masks(masks[:, :, i], [box_labels == (i + 1)]), np.multiply(box_labels == (i + 1), dilated_mask)])
                        dilated_masks.append(np.multiply(box_labels == (i + 1), dilated_mask))

                    masks = np.stack(dilated_masks, axis = -1)

                img_name = dataset.image_info[idx]['name']
        
                ImageId_batch, EncodedPixels_batch = f.numpy2encoding_no_overlap_threshold(masks, img_name, scores)
                ImageId += ImageId_batch
                EncodedPixels += EncodedPixels_batch

                if False:
                    class_names = ['background', 'nucleus']
                    visualize.display_instances((images[j] * 255).astype(np.uint8), r[j]['rois'], r[j]['masks'], r[j]['class_ids'], class_names, r[j]['scores'], figsize = (8, 8))
                    
                if save_predictions:
                    # Extract final masks from EncodedPixels_batch here and save
                    # using filename: (mosaic_id)_(mosaic_position)_(img_name).npy
                    save_model_predictions(save_dir, EncodedPixels_batch, masks.shape[:2], dataset.image_info[idx])


    if create_submission:
        submission_filename = os.path.join(submissions_dir, '_'.join(('submission', _config.NAME, str(epoch), datetime.datetime.now().strftime('%Y%m%d%H%M%S'), '.csv')))
        f.write2csv(submission_filename, ImageId, EncodedPixels)
        return submission_filename

    return ImageId, EncodedPixels


def predict_gt_model(_config, dataset, model_name='MaskRCNN', epoch = None, 
                  augment_flips = False, augment_scale = False, 
                  param_dict = {},
                  nms_threshold = 0.3, voting_threshold = 0.5,
                  use_semantic = False,
                  img_pad = 0, dilate = False, 
                  save_predictions = False, create_submission = True):

    # Recreate the model in inference mode
    model = create_model(_config, model_name, epoch)
      
    ImageId = []
    EncodedPixels = []
    
    list_fn_apply = [] + (['apply_flips_rotations'] if augment_flips else []) + (['apply_scaling'] if augment_scale else [])
    
    if dilate:
        n_dilate = param_dict['n_dilate'] if 'n_dilate' in param_dict else 1

    # NB: we need to predict in batches of _config.BATCH_SIZE
    # as there are layers within the model that have strides dependent on this.
    for i in tqdm(range(0, len(dataset.image_ids), _config.BATCH_SIZE)):
         # Load image
        images = []
        gt = []
        N = 0
        for idx in range(i, i + _config.BATCH_SIZE):
            if idx < len(dataset.image_ids):
                N += 1
                if img_pad > 0:
                    img = dataset.load_image(dataset.image_ids[idx])                  
                    images.append(np.stack([np.pad(img[:, :, i], img_pad, mode = 'reflect') for i in range(img.shape[-1])], axis = -1))
                else:
                    images.append(dataset.load_image(dataset.image_ids[idx]))
                    gt.append(dataset.load_mask(dataset.image_ids[idx])[0])
            else:
                images.append(images[-1])
                gt.append(gt[-1])

        # Run detection
        if len(list_fn_apply) > 0:
            r = maskrcnn_detect_augmentations(_config, model, images, list_fn_apply, 
                                              threshold = nms_threshold, voting_threshold = voting_threshold, 
                                              param_dict = param_dict, 
                                              use_nms = False, use_semantic = use_semantic)
        else:
            r = maskrcnn_detect(_config, model, images, param_dict = param_dict, use_semantic = use_semantic) 

        # Reduce to N images
        for j, idx in enumerate(range(i, i + _config.BATCH_SIZE)):      

            if j < N:   

                masks = r[j]['masks'] #[H, W, N] instance binary masks
                scores = r[j]['scores']
                boxes = r[j]['rois']

                if img_pad > 0:

                    if use_semantic:
                        r[j]['semantic_masks'] = r[j]['semantic_masks'][img_pad : -img_pad, img_pad : -img_pad]

                    masks = masks[img_pad : -img_pad, img_pad : -img_pad]
                    valid = np.sum(masks, axis = (0, 1)) > 0
                    masks = masks[:, :, valid]

                    r[j]['masks'] = masks
                    r[j]['scores'] = r[j]['scores'][valid]
                    r[j]['class_ids'] = r[j]['class_ids'][valid]
                    r[j]['rois'] = r[j]['rois'][valid]
   
                if dilate:

                    # Dilate masks within boundary box perimeters
                    box_labels = du.maskrcnn_boxes_to_labels(boxes, scores, masks.shape[:2])
                    dilated_masks = []
                    for i in range(masks.shape[-1]):
                        dilated_mask = scipy.ndimage.morphology.binary_dilation(masks[:, :, i], iterations = n_dilate)
                        #from visualize import plot_multiple_images, image_with_masks;                   
                        #plot_multiple_images([image_with_masks(masks[:, :, i], [box_labels == (i + 1)]), np.multiply(box_labels == (i + 1), dilated_mask)])
                        dilated_masks.append(np.multiply(box_labels == (i + 1), dilated_mask))

                    masks = np.stack(dilated_masks, axis = -1)

                gt_labels = du.maskrcnn_mask_to_labels(gt[j])
                mask_labels = du.maskrcnn_mask_to_labels(masks)
                plot_multiple_images([images[j], 
                                    gt_labels,
                                    mask_labels,
                                    image_with_masks(images[j], [gt_labels, mask_labels]),
                                    np.multiply(mask_labels, np.logical_and(mask_labels > 0, gt_labels > 0)),
                                    np.multiply(mask_labels, np.logical_and(mask_labels > 0, gt_labels == 0))],
                                    ['img'] + ['_'.join(('GT_labels', str(np.max(gt_labels))))] + ['_'.join(('Predicted_labels', str(np.max(mask_labels))))] + ['img_with_labels']+ ['predicted_correct'] + ['predicted_incorrect'],
                                    nrows = 2, ncols = 3)


    return 



def predict_multiple_concat(configs, datasets, model_name='MaskRCNN', epoch = None, 
                  augment_flips = False, augment_scale = False, 
                  param_dict = {},
                  use_semantic = False,
                  nms_threshold = 0.3, voting_threshold = 0.5,
                  img_pad = 0, dilate = False, 
                  save_predictions = False, create_submission = True):

    ImageId = []
    EncodedPixels = []

    for _config, dataset in zip(configs, datasets):
        
        _ImageId, _EncodedPixels = predict_model(_config, dataset, model_name = model_name, epoch = epoch, 
                                                  augment_flips = augment_flips, augment_scale = augment_scale, 
                                                  param_dict = param_dict,
                                                  nms_threshold = nms_threshold, voting_threshold = voting_threshold,
                                                  img_pad = img_pad, dilate = dilate, 
                                                  save_predictions = save_predictions, create_submission = False)
        ImageId += _ImageId
        EncodedPixels += _EncodedPixels

    if create_submission:                   

        f.write2csv(os.path.join(submissions_dir, '_'.join(('submission', 
                                                        '_'.join([_config.NAME for _config in configs]), 
                                                        str(epoch), datetime.datetime.now().strftime('%Y%m%d%H%M%S'), '.csv'))), ImageId, EncodedPixels)


def predict_nms(configs, datasets, epoch = None, augment_flips = False, augment_scale = False, nms_threshold = 0.3, save_predictions = False, create_submission = True):

    # Create save_dir
    if save_predictions:
        save_dir = os.path.join(data_dir, configs[0].NAME, '_'.join(('submission', datetime.datetime.now().strftime('%Y%m%d%H%M%S'))))
        os.makedirs(save_dir)

    ImageId = []
    EncodedPixels = []

    models = [create_model(_config, epoch) for _config in configs]
    n_images = len(datasets[0].image_ids)
    batch_size = max([_config.BATCH_SIZE for _config in configs])

    # NB: we need to predict in batches of _config.BATCH_SIZE
    # as there are layers within the model that have strides dependent on this.
    for i in range(0, n_images, batch_size):

        images = [load_dataset_images(dataset, i, batch_size) for dataset in datasets]

        # Run detection
        res = []
        for model, _images, _configs in zip(models, images, configs):
            if _configs.BATCH_SIZE == batch_size:
                res.append(model.detect(_images, verbose=0))
            else:
                assert _configs.BATCH_SIZE == 1
                res.append([model.detect([img], verbose=0)[0] for img in _images])
        
        # Reduce to N images
        for j, idx in enumerate(range(i, i + batch_size)):      

            if idx < n_images:   

                # Get masks via nms
                rois = np.concatenate([r[j]['rois'] for r in res])
                scores = np.concatenate([r[j]['scores'] for r in res])
                masks = np.moveaxis(np.concatenate([np.moveaxis(r[j]['masks'], -1, 0) for r in res]), 0, -1)

                nms_idx = utils.non_max_suppression(rois, scores, nms_threshold)

                masks = masks[:, :, nms_idx]
                scores = scores[nms_idx]
                rois = rois[nms_idx]
                
                img_name = datasets[0].image_info[idx]['name']
        
                ImageId_batch, EncodedPixels_batch = f.numpy2encoding_no_overlap_threshold(masks, img_name, scores)
                ImageId += ImageId_batch
                EncodedPixels += EncodedPixels_batch

                if False:
                    class_names = ['background', 'nucleus']
                    visualize.display_instances((images[j] * 255).astype(np.uint8), rois, masks, np.ones(scores.shape, dtype = np.int), class_names, scores, figsize = (8, 8))
                    
                if save_predictions:
                    # Extract final masks from EncodedPixels_batch here and save
                    # using filename: (mosaic_id)_(mosaic_position)_(img_name).npy
                    save_model_predictions(save_dir, EncodedPixels_batch, masks.shape[:2], dataset.image_info[idx])


    if create_submission:
        f.write2csv(os.path.join(submissions_dir, '_'.join(('submission_nms', 
                                                    '_'.join([_config.NAME for _config in configs]), 
                                                    str(epoch), datetime.datetime.now().strftime('%Y%m%d%H%M%S'), '.csv'))), ImageId, EncodedPixels)


def predict_voting(configs, datasets, model_name='MaskRCNN', epoch = None, 
                  augment_flips = False, augment_scale = False, 
                  param_dict = {},
                  use_semantic = False,
                  nms_threshold = 0.3, voting_threshold = 0.5,
                  img_pad = 0, dilate = False, 
                  save_predictions = False, create_submission = True):
    """
    Predicts an ensemble over multiple models via voting
    Presently assumes that epoch/augment_flips/scal/param_dict/threshold/use_semantic are the same 
    for all models you want to ensemble. Need to reformat to make these specific to each model.
    """
    # Create save_dir
    if save_predictions:
        save_dir = os.path.join(data_dir, configs[0].NAME, '_'.join(('submission', datetime.datetime.now().strftime('%Y%m%d%H%M%S'))))
        os.makedirs(save_dir)

    ImageId = []
    EncodedPixels = []

    models = [create_model(_config, epoch) for _config in configs]
    n_images = len(datasets[0].image_ids)
    batch_size = max([_config.BATCH_SIZE for _config in configs])

    # NB: we need to predict in batches of _config.BATCH_SIZE
    # as there are layers within the model that have strides dependent on this.
    for i in range(0, n_images, batch_size):

        images = [load_dataset_images(dataset, i, batch_size) for dataset in datasets]

        # Run detection
        res = []
        for model, _images, _config in zip(models, images, configs):

            if _configs.BATCH_SIZE == batch_size:

                # Run detection
                if len(list_fn_apply) > 0:
                    r = maskrcnn_detect_augmentations(_config, model, _images, list_fn_apply, 
                                                      threshold = nms_threshold, voting_threshold = voting_threshold, 
                                                      param_dict = param_dict, 
                                                      use_nms = False, use_semantic = use_semantic)
                else:
                    r = maskrcnn_detect(_config, model, _images, param_dict = param_dict, use_semantic = use_semantic) 
                res.append(r)

            else:

                assert _configs.BATCH_SIZE == 1

                r = []
                for img in _images:
                    # Run detection
                    if len(list_fn_apply) > 0:
                        r.append(maskrcnn_detect_augmentations(_config, model, img, list_fn_apply, 
                                                          threshold = nms_threshold, voting_threshold = voting_threshold, 
                                                          param_dict = param_dict, 
                                                          use_nms = False, use_semantic = use_semantic))
                    else:
                        r.append(maskrcnn_detect(_config, model, img, param_dict = param_dict, use_semantic = use_semantic))

                res.append(r)
        
        # Reduce to N images
        for j, idx in enumerate(range(i, i + batch_size)):      

            if idx < n_images:   

                # Get masks via voting
                
                # First reshape masks so that they can be concatenated:
                for r in res:
                    r[j]['masks'] = np.moveaxis(r[j]['masks'], -1, 0)
                
                # Concatenate
                img_results = du.concatenate_list_of_dicts([r[j] for r in res])

                # Reduce via voting
                img_results = reduce_via_voting(img_results, threshold, voting_threshold, param_dict, use_semantic = use_semantic, n_votes = len(models))

                img_name = datasets[0].image_info[idx]['name']
        
                ImageId_batch, EncodedPixels_batch = f.numpy2encoding_no_overlap_threshold(img_results['masks'], img_name, img_results['scores'])
                ImageId += ImageId_batch
                EncodedPixels += EncodedPixels_batch

                if False:
                    class_names = ['background', 'nucleus']
                    visualize.display_instances((images[j] * 255).astype(np.uint8), rois, masks, np.ones(scores.shape, dtype = np.int), class_names, scores, figsize = (8, 8))
                    
                if save_predictions:
                    # Extract final masks from EncodedPixels_batch here and save
                    # using filename: (mosaic_id)_(mosaic_position)_(img_name).npy
                    save_model_predictions(save_dir, EncodedPixels_batch, img_results['masks'].shape[:2], dataset.image_info[idx])


    if create_submission:
        f.write2csv(os.path.join(submissions_dir, '_'.join(('submission_nms', 
                                                    '_'.join([_config.NAME for _config in configs]), 
                                                    str(epoch), datetime.datetime.now().strftime('%Y%m%d%H%M%S'), '.csv'))), ImageId, EncodedPixels)


def predict_labels(_config, dataset, epoch = None):

    # Recreate the model in inference mode
    model = create_model(_config, epoch)
    
    labels, scores = [], []
    # NB: we need to predict in batches of _config.BATCH_SIZE
    # as there are layers within the model that have strides dependent on this.
    for i in range(0, len(dataset.image_ids), _config.BATCH_SIZE):
         # Load image
        images = []
        N = 0
        for idx in range(i, i + _config.BATCH_SIZE):
            if idx < len(dataset.image_ids):
                N += 1
                images.append(dataset.load_image(dataset.image_ids[idx]))
            else:
                images.append(images[-1])

        # Run detection
        r = model.detect(images, verbose=0)
        
        # Reduce to N images
        for j, idx in enumerate(range(i, i + _config.BATCH_SIZE)):      

            if j < N:   

                masks = r[j]['masks'] #[H, W, N] instance binary masks
                
                labels.append(du.maskrcnn_mask_to_labels(masks))
                scores.append(r[j]['scores'])
                
    return np.array(labels), np.array(scores)


def predict_mosaics_plus_originals(configs, datasets, epoch = None, augment_flips = False, augment_scale = False, nms_threshold = 0.3, save_predictions = False, create_submission = True):
    """
    Predict mosaics (config/dataset 0); deconstruct to originals.
    Predict originals (config/dataset 1).
    Combine mosaics with originals that have no overlap with mosaics (excluding originals that cross an edge... edge cases unreliable).
    """

    # Create save_dir
    if save_predictions:
        save_dir = os.path.join(data_dir, configs[0].NAME, '_'.join(('submission', datetime.datetime.now().strftime('%Y%m%d%H%M%S'))))
        os.makedirs(save_dir)

    assert len(configs) == len(datasets) == 2

    ImageId = []
    EncodedPixels = []

    # Predict full mosaic images using predict_mosaic_labels + configs/datasets[0]
    mosaic_id = np.array([int(datasets[0].image_info[i]['mosaic_id']) for i in range(len(datasets[0].image_ids))])
    mosaic_labels, mosaic_scores = predict_labels(configs[0], datasets[0], epoch = epoch)

    # Extract mosaic info from the original images
    n_images = len(datasets[1].image_ids)
    orig_names = np.array([datasets[1].image_info[i]['name'] for i in range(n_images)])
    orig_mosaic_id = np.array([datasets[1].image_info[i]['mosaic_id'] for i in range(n_images)])
    orig_mosaic_position = np.array([datasets[1].image_info[i]['mosaic_position'] for i in range(n_images)])

    # Predict original images using predict_labels + configs/datasets[1]
    labels, scores = predict_labels(configs[1], datasets[1], epoch = epoch)

    # Combine mosaic predictions with originals, giving preference to mosaics
    assert np.array_equal(np.unique(mosaic_id), np.unique(orig_mosaic_id))

    for mosaic in np.unique(mosaic_id):

        mosaic_idx = np.argwhere(orig_mosaic_id == mosaic).reshape(-1,)

        if len(mosaic_idx) > 1:
            # Image is part of a mosaic.
            # Order the original predictions according to down-left/down-right/up-left/up-right
            _orig_names = orig_names[mosaic_idx]
            _orig_mosaic_position = orig_mosaic_position[mosaic_idx]
            _orig_labels = labels[mosaic_idx]
            _orig_scores = scores[mosaic_idx]

            final_labels, final_scores, final_names = combine_mosaics(_orig_names, _orig_mosaic_position, _orig_scores, _orig_labels, 
                                                                      mosaic_labels[mosaic_id == mosaic][0], mosaic_scores[mosaic_id == mosaic][0])

            # Add to predictions
            for fl, fs, img_name, pos in zip(final_labels, final_scores, final_names, ['down_left', 'down_right', 'up_left', 'up_right']):

                masks = du.maskrcnn_labels_to_mask(fl)        
                ImageId_batch, EncodedPixels_batch = f.numpy2encoding_no_overlap_threshold(masks, img_name, fs)
                ImageId += ImageId_batch
                EncodedPixels += EncodedPixels_batch

                if save_predictions:
                    # Extract final masks from EncodedPixels_batch here and save
                    # using filename: (mosaic_id)_(mosaic_position)_(img_name).npy
                    image_info = {'mosaic_id': mosaic, 'mosaic_position': pos, 'name': img_name}
                    save_model_predictions(save_dir, EncodedPixels_batch, masks.shape[:2], image_info)

        else:
            # Predictions are the same as image not part of a mosaic
            masks = du.maskrcnn_labels_to_mask(labels[mosaic_idx][0])
            img_name = datasets[1].image_info[mosaic_idx[0]]['name']
        
            ImageId_batch, EncodedPixels_batch = f.numpy2encoding_no_overlap_threshold(masks, img_name, scores[mosaic_idx][0])
            ImageId += ImageId_batch
            EncodedPixels += EncodedPixels_batch

            if save_predictions:
                # Extract final masks from EncodedPixels_batch here and save
                # using filename: (mosaic_id)_(mosaic_position)_(img_name).npy
                save_model_predictions(save_dir, EncodedPixels_batch, masks.shape[:2], datasets[1].image_info[mosaic_idx[0]])

    if create_submission:
        f.write2csv(os.path.join(submissions_dir, '_'.join(('submission_mosaics', 
                                                    configs[0].NAME, 
                                                    str(epoch), datetime.datetime.now().strftime('%Y%m%d%H%M%S'), '.csv'))), ImageId, EncodedPixels)


def predict_tiled_model(_config, dataset, epoch = None, area_threshold = 0, nuclei_threshold = 0,
                        grid_shape = (2, 2), nms_threshold = 0.3, nms_tiles = False, save_predictions = False, create_submission = True):
    """
    Predict masks for each image by splitting the original image up into tiles,
    making predictions for these, and subsequently stitching them back together.
    Only predict via tiling if the image area is > area_threshold or number of predicted nuclei > nuclei_threshold. 
    Otherwise detect as normal.
    """

    # Create save_dir
    if save_predictions:
        save_dir = os.path.join(data_dir, _config.NAME, '_'.join(('submission', datetime.datetime.now().strftime('%Y%m%d%H%M%S'))))
        os.makedirs(save_dir)

    # Recreate the model in inference mode
    model = create_model(_config, epoch)
      
    ImageId = []
    EncodedPixels = []
    
    # NB: we need to predict in batches of _config.BATCH_SIZE
    # as there are layers within the model that have strides dependent on this.
    for i in range(0, len(dataset.image_ids), _config.BATCH_SIZE):
         # Load image
        images = []
        N = 0
        for idx in range(i, i + _config.BATCH_SIZE):
            if idx < len(dataset.image_ids):
                N += 1
                images.append(dataset.load_image(dataset.image_ids[idx]))
            else:
                images.append(images[-1])

        # Run detection
        # maskrcnn_detect_tiles if img_size > pixel_threshold or num nuclei > nuclei_threshold else regular detection
        # NB: We detect for all images in each case as we need to keep batch sizes consistent
            
        r_orig = model.detect(images)

        img_area = [np.product(img.shape[:2]) for img in images]
        n_nuclei = [_r['masks'].shape[-1] for _r in r_orig]
        detect_tiles = [(s > area_threshold) or (n > nuclei_threshold) for s, n in zip(img_area, n_nuclei)]

        if np.any(detect_tiles):
            r_tiles = maskrcnn_detect_tiles(model, images, grid_shape = grid_shape, nms_threshold = nms_threshold, nms_tiles = nms_tiles)

        r = [r_tiles[j] if detect_tiles[j] else r_orig[j] for j in range(len(detect_tiles))]

        # Reduce to N images
        for j, idx in enumerate(range(i, i + _config.BATCH_SIZE)):      

            if j < N:   

                masks = r[j]['masks'] #[H, W, N] instance binary masks
                img_name = dataset.image_info[idx]['name']
        
                ImageId_batch, EncodedPixels_batch = f.numpy2encoding_no_overlap_threshold(masks, img_name, r[j]['scores'])
                ImageId += ImageId_batch
                EncodedPixels += EncodedPixels_batch

                if save_predictions:
                    # Extract final masks from EncodedPixels_batch here and save
                    # using filename: (mosaic_id)_(mosaic_position)_(img_name).npy
                    save_model_predictions(save_dir, EncodedPixels_batch, masks.shape[:2], dataset.image_info[idx])


    if create_submission:
        f.write2csv(os.path.join(submissions_dir, '_'.join(('submission', 
                                                        _config.NAME, 
                                                        str(epoch), 
                                                        str(grid_shape[0]), 
                                                        str(nms_threshold), 
                                                        datetime.datetime.now().strftime('%Y%m%d%H%M%S'), '.csv'))), ImageId, EncodedPixels)


def predict_scaled_model(_config, dataset, epoch = None, nms_threshold = 0.3, save_predictions = False, create_submission = True):
    """
    Predict in two phases:
    1) predict as normal and estimate avg nucleus size
    2) rescale test images according to the model's training avg nucleus size and predict again
    """

    # Create save_dir
    if save_predictions:
        save_dir = os.path.join(data_dir, _config.NAME, '_'.join(('submission', datetime.datetime.now().strftime('%Y%m%d%H%M%S'))))
        os.makedirs(save_dir)

    # Recreate the model in inference mode
    model = create_model(_config, epoch)

    # Retrieve the avg mask size
    assert _config.mask_size_filename is not None
    model_mask_size = np.load(_config.mask_size_filename)
    model_mask_size = np.mean(model_mask_size[np.logical_not(np.isnan(model_mask_size))])
      
    ImageId = []
    EncodedPixels = []
    
    # NB: we need to predict in batches of _config.BATCH_SIZE
    # as there are layers within the model that have strides dependent on this.
    for i in range(0, len(dataset.image_ids), _config.BATCH_SIZE):
         # Load image
        images = []
        N = 0
        for idx in range(i, i + _config.BATCH_SIZE):
            if idx < len(dataset.image_ids):
                N += 1
                images.append(dataset.load_image(dataset.image_ids[idx]))
            else:
                images.append(images[-1])

        # Run detection
        _r = model.detect(images, verbose=0)
        
        # Estimate the mask size 
        avg_mask_size = []
        for j in range(_config.BATCH_SIZE):                 
            masks = _r[j]['masks'] 
            #NB: need to resize to model input scale so that is comparable with recorded model_mask_size
            _, window, scale, padding = utils.resize_image(images[j], min_dim = _config.IMAGE_MIN_DIM, max_dim = _config.IMAGE_MAX_DIM, padding = _config.IMAGE_PADDING)
            resized_masks = utils.resize_mask(masks, scale, padding)
            avg_mask_size.append(np.mean(np.sum(resized_masks, axis = (0, 1))))

        # Detect again, but with images scaled according to predicted mask size
        r = model.detect(images, verbose = 0, mask_scale = [np.sqrt(model_mask_size / x) for x in avg_mask_size])

        for j, idx in enumerate(range(i, i + _config.BATCH_SIZE)):      

            if j < N:   

                masks = r[j]['masks'] #[H, W, N] instance binary masks
                img_name = dataset.image_info[idx]['name']
        
                ImageId_batch, EncodedPixels_batch = f.numpy2encoding_no_overlap_threshold(masks, img_name, r[j]['scores'])
                ImageId += ImageId_batch
                EncodedPixels += EncodedPixels_batch

                if save_predictions:
                    # Extract final masks from EncodedPixels_batch here and save
                    # using filename: (mosaic_id)_(mosaic_position)_(img_name).npy
                    save_model_predictions(save_dir, EncodedPixels_batch, masks.shape[:2], dataset.image_info[idx])


    if create_submission:
        f.write2csv(os.path.join(submissions_dir, '_'.join(('submission_scaled', _config.NAME, str(epoch), datetime.datetime.now().strftime('%Y%m%d%H%M%S'), '.csv'))), ImageId, EncodedPixels)


def save_model_predictions(save_dir, EncodedPixels_batch, mask_shape, image_info):
    """
    Saves labels from predictions
    """
    if EncodedPixels_batch != ['']:
        labels, masks = du.labels_from_rles(EncodedPixels_batch, mask_shape)
    else:
        labels = np.zeros(mask_shape)
                    
    mosaic_id = image_info['mosaic_id'] if 'mosaic_id' in image_info else 'None'
    mosaic_position = image_info['mosaic_position'] if 'mosaic_position' in image_info else 'None'
    save_filename = os.path.join(save_dir, '_'.join((str(mosaic_id), str(mosaic_position), image_info['name'], '.npy')))

    np.save(save_filename, labels)

    return 


def predict_experiment(fn_experiment, fn_predict = 'predict_model', **kwargs):
    _config, dataset, model_name = fn_experiment(training=False)
    submission_filename = globals()[fn_predict](_config, dataset, model_name, **kwargs)

    if submission_filename is not None:
        epoch = 'last' if 'epoch' not in kwargs else kwargs['epoch']
        print("\nkaggle competitions submit -f {} -m 'experiment {} @ epoch {}'".format(
            submission_filename,
            fn_experiment.__name__,
            epoch
            )
        )


def main():
    if getpass.getuser() == 'antor':
        predict_experiment(train.train_resnet101_flipsrot_minimask12_double_invert_semantic, 'predict_model')
    else:
        #predict_experiment(train.train_resnet101_flips_all_rots_data_minimask12_mosaics_nsbval, 'predict_model', create_submission = False, save_predictions = True)
       
        predict_experiment(train.trainsupp_resnet101_flipsrot_minimask12_no_invert_semantic_config2, 'predict_gt_model')


if __name__ == '__main__':
    main()
    
    
