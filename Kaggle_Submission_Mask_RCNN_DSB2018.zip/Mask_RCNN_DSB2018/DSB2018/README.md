For  https://www.kaggle.com/c/data-science-bowl-2018.

Use Mask R-CNN like methods based on [Mask R-CNN for object detection and instance segmentation on Keras and TensorFlow](https://github.com/matterport/Mask_RCNN)

